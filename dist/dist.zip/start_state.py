import game_framework
from pico2d import *


# fill here

def enter():
    # fill here
    pass


def exit():
    # fill here
    pass

def update(frame_time):
    # fill here
    pass

def draw(frame_time):
    # fill here
    pass

def handle_events(frame_time):
    events = get_events()

def pause(): pass
def resume(): pass




